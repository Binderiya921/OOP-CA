/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeepolyapp;

/**
 *
 * @author pminj
 */
public class Manager extends Employee {
    private double salary;

    public Manager(double salary, String name, String dob, String id) {
        super(name, dob, id);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
  
    @Override
    public String printDetails(){
        return super.printDetails()+","+salary;
    }
    @Override
     public double computeWeeklyPay(){
        return salary/52;
    }
}
