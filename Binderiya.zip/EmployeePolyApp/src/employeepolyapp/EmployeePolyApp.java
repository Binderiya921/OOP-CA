/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeepolyapp;

/**
 *
 * @author pminj
 */
public class EmployeePolyApp {
    public static void main(String[] args) {
        
        Employee e = new Employee("Jackie", "23413921", "21/09/2006");
        Manager m = new Manager(50000, "Clare", "874928h", "21/12/1995");
        CasualStaff c = new CasualStaff ( 24, 14.05, "John", "87br3b", "03/03/2002");
        
        System.out.println("Employee details: " +e.getName()+","+e.getId()+","+e.getDob());
        System.out.println("Employee details: " +m.getName()+","+m.getId()+","+m.getDob()+","+m.getSalary());
        System.out.println("Employee details: " +c.getName()+","+c.getId()+","+c.getDob()+","+c.getHours()+","+c.getRate());
        
        System.out.println(e.printDetails());
        System.out.println(m.printDetails());
        System.out.println(c.printDetails());
        
        System.out.println("Employee pay: "+m.computeWeeklyPay());
        System.out.println("Employee pay: "+c.computeWeeklyPay());
        
        //polymorphism and objects
        Employee e2 = new Manager(60000, "Peter", "13/08/2000", "873yih2");
        System.out.println("E2 "+e2.printDetails());
        System.out.println("E2 details: "+e2.computeWeeklyPay());
        
        e2.setName("Pauls");
        //e2.setSalary(40000) won't work
        if(e2 instanceof Manager){
            Manager m2 = (Manager) e2;
            m2.setSalary(40000);  
        }
        System.out.println("E2 updated "+e2.printDetails());
    } 
}
