/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeepolyapp;

/**
 *
 * @author pminj
 */
public class CasualStaff extends Employee{
    private double hours;
    private double rate;

    public CasualStaff(double hours, double rate, String name, String dob, String id) {
        super(name, dob, id);
        this.hours = hours;
        this.rate = rate;
    }

    public double getHours() {
        return hours;
    }

    public void setHours(double hours) {
        this.hours = hours;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
    
    @Override
    public String printDetails(){
        return super.printDetails()+","+hours+","+rate;
    }
    @Override
     public double computeWeeklyPay(){
        return hours*rate;
    }
}
